<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                

                  <?php if(session()->get('success')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>  
                    </div><br />
                 <?php elseif(session()->get('error')): ?> 

                    <div class="alert alert-danger">
                      <?php echo e(session()->get('error')); ?>  
                    </div><br />
                 
                 <?php endif; ?>
                
                <div class="card-body">

                <?php if(Route::current()->getName()=='EditUser'): ?>

                    <div class="card-header">Update a user</div>
                    <br>

                    <form method="POST" action="<?php echo e(route('UpdateUser')); ?>">

                        <input  type="hidden"  name="id" value="<?php echo e($datas->id); ?>">

                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($datas->name); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($datas->email); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> 


                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Assign Role</label>

                            <div class="col-md-6">
                                <select name="role_id" class="form-control">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($datas->role_id==$role->id): ?>
                                            <option value="<?php echo e($role->id); ?>" selected="selected"><?php echo e($role->name); ?></option>
                                        <?php else: ?>    
                                             <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>



                         <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Assign Team</label>

                            <div class="col-md-6">
                                
                                <?php
                                $teamCol = explode(',',$datas->assigned_teams);
                                ?>

                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if(in_array($team->id,$teamCol)): ?>

                                    <input id="teams" type="checkbox" class="" name="assigned_teams[]" value="<?php echo e($team->id); ?>" checked><?php echo e($team->name); ?> <br>

                                <?php else: ?> 

                                    <input id="teams" type="checkbox" class="" name="assigned_teams[]" value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?> <br>

                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                
                            </div>
                        </div>

                         <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Assign Team Owner</label>

                            <div class="col-md-6">

                                 <select name="assigned_team_owner" class="form-control">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($datas->assigned_team_owner==$team->id): ?>
                                            <option value="<?php echo e($team->id); ?>" selected="selected"><?php echo e($team->name); ?></option>
                                        <?php else: ?>    
                                             <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                            </div>
                        </div>




                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Update')); ?>

                                </button>
                            </div>
                        </div>
                    </form>


                    <?php else: ?> 
                    
                    <div class="card-header">Add a new user</div>
                    <br>

                    <form method="POST" action="<?php echo e(route('users')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Assign Role</label>

                            <div class="col-md-6">
                                <select name="role_id" class="form-control">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>



                         <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Assign Team</label>

                            <div class="col-md-6">
                                
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <input id="teams" type="checkbox" class="" name="assigned_teams[]" value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?> <br>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                
                            </div>
                        </div>


                         <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Assign Team Owner</label>

                            <div class="col-md-6">

                                 <select name="assigned_team_owner" class="form-control">
                                        <option value="">Select</option>
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                            </div>
                        </div>


                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>




                    <?php endif; ?>

                    <br>

                       <table class="table table-striped table-hover table-users">
                            <thead>
                                <tr>                                    
                                    <th class="hidden-phone">Name</th>                                   
                                    <th class="hidden-phone">Email</th>                                   
                                    <th class="hidden-phone">Role</th>                                   
                                    <th class="hidden-phone">Teams</th>                                   
                                    <th class="hidden-phone">Owner of Team</th>                                   
                                    <th>Edit</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>

                            <tbody>
                                
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <tr>                                    
                                    <td class="hidden-phone"><?php echo e($user->name); ?></td>                                    
                                    <td class="hidden-phone"><?php echo e($user->email); ?></td>                                    
                                    <td class="hidden-phone"><?php echo e($user->rname); ?></td>                                    
                                    <td class="hidden-phone">
                                        
                                        <?php
                                        $teamCol = explode(',',$user->assigned_teams);
                                        ?>

                                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if(in_array($team->id,$teamCol)): ?>

                                            <?php echo e($team->name); ?><br>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    </td>  

                                    <td class="hidden-phone">
                                                                              
                                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($team->id==$user->assigned_team_owner): ?>

                                            <?php echo e($team->name); ?><br>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    </td> 
                                     <?php if($user->role_id!=1): ?>
                                        <td><a class="btn mini blue-stripe" href="<?php echo e(url('/edituser/'.$user->id)); ?>">Edit</a></td>    
                                        <td><a href="<?php echo e(url('/deleteuser/'.$user->id)); ?>" class="confirm-delete btn mini red-stripe" role="button"   data-title="johnny" data-id="1">Delete</a></td>

                                     <?php else: ?> 
                                        <td><a class="btn mini blue-stripe" href="<?php echo e(url('/edituser/'.$user->id)); ?>">Edit</a></td>
                                        <td></td>

                                     <?php endif; ?>                                  
                                   
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                               </tbody>

                        </table>
            
                        <?php echo e($users->links()); ?>

                  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>