<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               
                <?php if(session()->get('success')): ?>
                    <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>  
                    </div><br />
                 <?php elseif(session()->get('error')): ?> 

                    <div class="alert alert-danger">
                      <?php echo e(session()->get('error')); ?>  
                    </div><br />
                 
                 <?php endif; ?>


                  <?php if(Route::current()->getName()=='EditRole'): ?>

                   <div class="card-header">Update a role</div>

                    <div class="card-body">

                        <form method="POST" action="<?php echo e(route('UpdateRole')); ?>">
                            <?php echo csrf_field(); ?>

                            <input  type="hidden"  name="id" value="<?php echo e($datas->id); ?>">

                            <div class="form-group row">
                                <label for="name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($datas->name); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>


                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Save')); ?>

                                </button>
                            </div>


                            </div>
                           
                            
                        </form>

                    </div>


                    <?php else: ?> 


                      <div class="card-header">Add a new role</div>

                        <div class="card-body">

                            <form method="POST" action="<?php echo e(route('roles')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row">
                                    <label for="name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                    <div class="col-md-6">
                                        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" autofocus>

                                        <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Save')); ?>

                                        </button>
                                    </div>

                                </div>

                                
                                
                            </form>
                        </div>


                    <?php endif; ?>

                     <br>

                       <table class="table table-striped table-hover table-users">
                            <thead>
                                <tr>                                    
                                    <th class="hidden-phone">Name</th>                                   
                                    <th>EDIT</th>
                                    <th>DELETE</th>
                                </tr>
                            </thead>

                            <tbody>
                                
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                                <tr>                                    
                                    <td class="hidden-phone"><?php echo e($role->name); ?></td>                       
                                    <td><a class="btn mini blue-stripe" href="<?php echo e(url('/editrole/'.$role->id)); ?>">Edit</a></td>

                                    <td>

                                        <?php if($role->id!=1): ?>    
                                        <a href="<?php echo e(url('/deleterole/'.$role->id)); ?>" class="confirm-delete btn mini red-stripe" role="button" data-title="johnny" data-id="1">Delete</a>                        
                                        <?php endif; ?>

                                    </td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                               </tbody>

                        </table>
            
                        <?php echo e($roles->links()); ?>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>